class Config:

  def __init__(self, bot):
    self.bot = bot

  muted_message = "You have been Succesfully Muted"
  mute_role_name = "Muted"
